import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";
import "dotenv/config";
import express from "express";
import multer from "multer";
import { PDFParse } from "pdf-parse";
import { embed } from "./lib/openai.js";
import { deleteBySource, insertDocuments } from "./lib/supabase.js";

const CHUNK_SIZE = 1000;
const CHUNK_OVERLAP = 200;

const upload = multer({ storage: multer.memoryStorage() });
const app = express();

app.post("/ingest", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      res.status(500).json({ error: "Upload a pdf file first" });
      return;
    }

    const parser = new PDFParse({
      data: new Uint8Array(req.file.buffer),
    });

    const parsed = await parser.getText();
    const text = parsed.text;

    if (!text.trim()) {
      res.status(400).json({ error: "No text found in pdf" });
      return;
    }

    const splitter = new RecursiveCharacterTextSplitter({
      chunkSize: CHUNK_SIZE,
      chunkOverlap: CHUNK_OVERLAP,
    });

    const chunks = await splitter.splitText(text);
    const embeddings = await await embed(chunks);

    const source = req.file.originalname;
    await deleteBySource(source);

    const rows = chunks.map((content, index) => ({
      content,
      metadata: { source, chunk_index: index },
      embedding: embeddings[index],
    }));

    await insertDocuments(rows);

    res.json({ ok: true, source, chunks: rows.length });
  } catch (error) {
    res.status(500).json({ error: "Error occured" });
  }
});

app.listen(3000, "127.0.0.1", () => {
  console.log(`Post to localhost 3000 ingest endpoint`);
});
